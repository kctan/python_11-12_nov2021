# https://www.bikeinn.com/bike/gore--wear-c3-thermo-long-sleeve-jersey/137533545/p

from urllib.request import Request, urlopen
from bs4 import BeautifulSoup

site= "https://www.bikeinn.com/bike/gore--wear-c3-thermo-long-sleeve-jersey/137533545/p"
hdr = {'User-Agent': 'Mozilla/5.0'}
req = Request(site,headers=hdr)
page = urlopen(req)
soup = BeautifulSoup(page, 'html.parser')

elements = soup.select("#total_dinamic") # 92.99 S$ 
print(elements)
price = elements[0].text
print("Current Price: " + elements[0].text)



import datetime

x = datetime.datetime.now()

helloFile = open("table.txt", "a")
helloFile.write(str(x) + "\tprice: " + price + "\n")
helloFile.close()
