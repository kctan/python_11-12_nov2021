a = 'python for java'
b = a.split(' ')
print(b) 

a = ['python', 'and', 'java']
b = '-'.join(a)
print(b)