scores = {'Mary':90, 'Ben':67}
for s in scores:
    print(s)
    
for s in scores:
    print(s, scores[s])
    
values = scores.values()
print(values)

print("printing the values... ")
for v in values:
    print(v)