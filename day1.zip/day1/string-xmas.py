for i in range(5):
    half = "#" * i
    print ("%5s%-5s" % (half, half))