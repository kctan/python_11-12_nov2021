import math
print("pi is " + str(math.pi))
print(math.sqrt(4))

math.
print("pi is approx %.4f" % (math.pi))
